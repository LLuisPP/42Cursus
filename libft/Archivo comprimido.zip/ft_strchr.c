/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lprieto- <lprieto-@student.42barcelona.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/14 13:06:05 by lprieto-          #+#    #+#             */
/*   Updated: 2023/10/11 22:24:48 by lprieto-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
	{
		if (s[i] == (unsigned char) c)
		{
			return ((char *) &s[i]);
		}
		i++;
	}
	if (s[i] == (unsigned char) c)
		return ((char *) &s[i]);
	return ((char *) 0);
}

/*int main(int argc, char **argv)
{
	if (argc != 3)
		return (0);
	printf("ft_strchr:%s \n", ft_strchr(argv[1], atoi(argv[2])));
	printf("strchr:%s", strchr(argv[1], atoi(argv[2])));
	return(0);
}*/

/* ************************************************************************** *
 *								FT_STRCHR
 *
 * DESCRIPCION:	se utiliza para buscar la primera ocurrencia del caracter que
 * recibe como parametro de entrada dentro del string
 * 
 * INPUT:	const char *s, int c
 * 
 * MAKE:	recorre el array de origen y compara el caracter con los del array
 *  
 * OUTPUT:	devuelve un char * a la posicion donde ha encontrado la primera
 * ocurrencia del caracter 'c' introducido. Si no tiene exito devuelve '\0'
 * 
 * ************************************************************************** */