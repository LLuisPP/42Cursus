/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lprieto- <lprieto-@student.42barcelona.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/23 08:34:40 by lprieto-          #+#    #+#             */
/*   Updated: 2023/10/23 22:00:44 by lprieto-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putstr(char *s)
{
	int	len;
	int	i;

	i = 0;
	if (!s)
	{
		ft_putstr("(null)");
		return (-1);
	}
	else
	{
		len = ft_strlen(s);
		i = 0;
		while (i <= len)
		{
			ft_putchar(s[i]);
			i++;
		}
	}
	return (i);
}