/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pholder.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lprieto- <lprieto-@student.42barcelona.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/23 12:40:31 by lprieto-          #+#    #+#             */
/*   Updated: 2023/10/23 21:41:17 by lprieto-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_pholder(char const *str, va_list args, int i, int j)
{
	if (str[j] == 'c')
		ft_putchar(va_arg(args, int));
	if (str[j] == 's')
		ft_putstr(va_arg(args, char *));
	/*if (str[j] == 'p')
		write (1, 'p', 1);*/
	if (str[j] == 'd')
		ft_putnbr(va_arg(args, int));
	/*if (str[j] == 'i')
		write (1, 'i', 1);
	if (str[j] == 'u')
		write (1, 'u', 1);
	if (str[j] == 'x')
		write (1, 'x', 1);
	if (str[j] == 'X')
		write (1, 'X', 1);
	if (str[j] == '%')
		write (1, '%', 1);*/
	return (i);
}
